﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ShoppingCart.BusinessLayer;
using System.Data;

namespace ShoppingCart.Admin
{
    public partial class Products : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)//loaded for the first time
            {
                GetProducts(0);
            }
        }
        private void GetProducts(int CategoryID)
        {
            ShoppingCartclass k = new ShoppingCartclass() { 
                CategoryID=CategoryID
            };                       
            gvAvailableProducts.DataSource = null;
            gvAvailableProducts.DataSource = k.GetAllProducts(); ;
            gvAvailableProducts.DataBind();
            
            
        }
    }
}