﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ShoppingCart.BusinessLayer;
using System.Data;

namespace ShoppingCart.Admin
{
    public partial class AddNewProducts : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack) //to check if this page has been loaded for the first time
            {
                GetCategories();
                AddSubmitEvent();
                if(Request.QueryString["alert"]=="success")
                {
                    Response.Write("<script>alert('record Saved Successfully')</script>");
                }
            }
        }
        private void AddSubmitEvent()  //This function will allow only this page to refresh..Others will not refresh on postback
        {
            UpdatePanel updatePanel = Page.Master.FindControl("AdminUpdatePanel") as UpdatePanel;
            UpdatePanelControlTrigger trigger = new PostBackTrigger();
            trigger.ControlID = btnsubmit.UniqueID;
            updatePanel.Triggers.Add(trigger);
        }
        public void GetCategories()
        {
            ShoppingCartclass k = new ShoppingCartclass();
            DataTable dt = k.GetCategories();
            if(dt.Rows.Count>0)
            {
                ddlProductCategory.DataValueField = "CategoryID"; //for binding the data to the dropdown list all four lines
                ddlProductCategory.DataTextField = "CategoryName";
                ddlProductCategory.DataSource = dt;
                ddlProductCategory.DataBind();
            }

        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            if(uploadProductPhoto.PostedFile!=null)
            {
                SaveProductPhoto();
                ShoppingCartclass k = new ShoppingCartclass()
                {
                    ProductName = txtProductName.Text,
                    ProductImage = "~/ProductImages/" + uploadProductPhoto.FileName,
                    ProductPrice = txtProductPrice.Text,
                    ProductDescription = txtProductDescription.Text,
                    CategoryID = Convert.ToInt32(ddlProductCategory.SelectedValue),
                    TotalProducts=Convert.ToInt32(txtProductQuantity.Text)

                };
                k.AddNewProduct();
                //Alert.Show("REcord Saved Successfully");
                ClearText();
                Response.Redirect("~/Admin/AddNewProducts.aspx?alert=success");
            }
                else
                {
                    Response.Write("<script>alert('Please upload the photo');</script>");
                }
          
            }
            private void ClearText()
            {
                uploadProductPhoto = null;
                txtProductDescription.Text = null;
                txtProductName.Text = null;
                txtProductPrice.Text = null;
                ddlProductCategory.SelectedValue = null;
                txtProductQuantity.Text = null;
            }
            private void SaveProductPhoto()
            {
                if(uploadProductPhoto.PostedFile!=null)
                {
                    string filename = uploadProductPhoto.PostedFile.FileName.ToString();
                    string fileExt = System.IO.Path.GetExtension(uploadProductPhoto.FileName);

                    //check filename length
                    if(filename.Length>97)
                    {
                        //show("Size shouldn't exceed 97 characters");
                        return;
                    }
                    // check file type
                    else if(fileExt !=".jpeg" && fileExt !=".jpg" && fileExt !=".png" && fileExt !=".bmp" )
                    {
                        //alert("Only the above formats are allowed");
                        return;
                    }
                    // check file size
                    else if(uploadProductPhoto.PostedFile.ContentLength>4000000)
                    {
                        //alert("the image size shouldn't exceed 4MB");
                        return;
                    }
                    else
                    {
                        uploadProductPhoto.SaveAs(Server.MapPath("~/ProductImages/" + filename));
                    }
                }

        }

            protected void ddlProductCategory_SelectedIndexChanged(object sender, EventArgs e)
            {

            }

          
            
    }
}