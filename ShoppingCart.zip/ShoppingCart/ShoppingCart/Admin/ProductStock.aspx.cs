﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ShoppingCart.BusinessLayer;
using System.Data;


namespace ShoppingCart.Admin
{
    public partial class ProductStock : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                GetCategories();
                GetAvailbleStock();

            }
        }

        protected void ddlCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            GetAvailbleStock();
        }
        private void GetAvailbleStock()
        {
            ShoppingCartclass k = new ShoppingCartclass
            {
                CategoryID =Convert.ToInt32(ddlCategory.SelectedValue),
                StockType=Convert.ToInt32(rblProductStock.SelectedValue)
            };
            DataTable dt=k.GetAvailableStock();
            if(dt.Rows.Count>0)
            {
                gvAvailableStock.DataSource=dt;
                gvAvailableStock.DataBind();
                gvAvailableStock.Visible=true;
                NoRecordsToDisplay.Visible=false;
            }
            else
            {
                gvAvailableStock.Visible = false;
                NoRecordsToDisplay.Visible = true;
            }


        }

        protected void rblProductStock_SelectedIndexChanged(object sender, EventArgs e)
        {
            GetAvailbleStock();

        }
        private void GetCategories()
        {
            ShoppingCartclass k = new ShoppingCartclass();
            DataTable dt = k.GetCategories();
            if(dt.Rows.Count>0)
            {
                ddlCategory.DataValueField = "CategoryID";
                ddlCategory.DataTextField = "CategoryName";
                ddlCategory.DataSource = dt;
                ddlCategory.DataBind();
                ddlCategory.Items.Add(new ListItem("All Products", "0", true));
                ddlCategory.SelectedValue = "0";

            }

        }
    }
}