﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ShoppingCart.Admin
{
    public partial class OrderDetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(Request.QueryString["Id"]))
            {
                string TransactionNo = Request.QueryString["Id"];
                usCustomerOrder1.TransactionNoText = TransactionNo;
            }
            if (!string.IsNullOrEmpty(Convert.ToString(Session["ShoppingCartAdmin"])))
            {
                usCustomerOrder1.IsAuthorisedToAddStatus = true;
            }
            else
            {
                usCustomerOrder1.IsAuthorisedToAddStatus = false;
                Response.Redirect("~/Admin/Login.aspx");
            }
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Admin/Login.aspx");
        }
    }
}