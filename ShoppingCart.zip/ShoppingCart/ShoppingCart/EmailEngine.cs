﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web;
using System.Net.Mail;
using System.Configuration;

namespace ShoppingCart
{
    public static class EmailEngine
    {
        public static void SendEmail(string recepientEmail,string subject, string body)
        {
            using(MailMessage mailMessage=new MailMessage())
            {
                mailMessage.From = new MailAddress(ConfigurationManager.AppSettings["UserName"]);
                mailMessage.Subject = subject;
                mailMessage.Body = body;
                mailMessage.IsBodyHtml = true;
                mailMessage.To.Add(new MailAddress(recepientEmail));
                SmtpClient smtp = new SmtpClient();
                smtp.Host = ConfigurationManager.AppSettings["Host"];
                System.Net.NetworkCredential NetWorkCred = new System.Net.NetworkCredential();
                NetWorkCred.UserName = ConfigurationManager.AppSettings["UserName"];
                NetWorkCred.Password = ConfigurationManager.AppSettings["Password"];
                smtp.UseDefaultCredentials = true;
                smtp.Credentials = NetWorkCred;
                smtp.Port = int.Parse(ConfigurationManager.AppSettings["Port"]);
                smtp.Send(mailMessage);
            }
        }
    }
}