﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;

namespace ShoppingCart.BusinessLayer
{
    public class ShoppingCartclass
    {
        public string CategoryName;
        public int CategoryID;
        public int StockType;
        public string ProductName;
        public string ProductImage;
        public string ProductPrice;
        public string ProductDescription;
        public int TotalProducts;
        public int TotalPrice;
        public string CustomerName;
        public string CustomerEmailID;
        public string CustomerAddress;
        public string CustomerPhoneNo;
        public string ProductList;
        public string PaymentMethod;
        public int CustomerID;
        public string OrderStatus;
        public string OrderNo;
        public int ProductID;
        public int Flag;
        public void AddNewCategory()
        {
            SqlParameter[] parameters=new SqlParameter[1];
            parameters[0] = DataLayer.DataAcess.AddParameter("@CategoryName",CategoryName,System.Data.SqlDbType.VarChar,200);
            DataTable dt = DataLayer.DataAcess.ExecuteDTbyProcedure("SP_AddNewCategory", parameters);
         }
        public void AddNewProduct()
        {
            SqlParameter[] parameters = new SqlParameter[6];
            parameters[0] = DataLayer.DataAcess.AddParameter("@ProductName", ProductName, System.Data.SqlDbType.VarChar, 300);
            parameters[1] = DataLayer.DataAcess.AddParameter("@ProductPrice", ProductPrice, System.Data.SqlDbType.Int, 100);
            parameters[2] = DataLayer.DataAcess.AddParameter("@ProductImage", ProductImage, System.Data.SqlDbType.VarChar, 500);
            parameters[3] = DataLayer.DataAcess.AddParameter("@ProductDescription", ProductDescription, System.Data.SqlDbType.VarChar, 1000);
            parameters[4] = DataLayer.DataAcess.AddParameter("@CategoryID", CategoryID, System.Data.SqlDbType.Int, 100);
            parameters[5] = DataLayer.DataAcess.AddParameter("@ProductQuantity",TotalProducts,System.Data.SqlDbType.Int,100);
            DataTable dt = DataLayer.DataAcess.ExecuteDTbyProcedure("SP_AddNewProduct", parameters);
        }
        public DataTable GetCategories()
        {
            SqlParameter[] parameters = new SqlParameter[0];
            DataTable dt = DataLayer.DataAcess.ExecuteDTbyProcedure("SP_GetAllCategories", parameters);
            return dt; 
        }   
        public DataTable GetCustomerId()
        {
            SqlParameter[] parameters = new SqlParameter[0];
            DataTable dt = DataLayer.DataAcess.ExecuteDTbyProcedure("SP_GetCustomerId", parameters);
            return dt; 
        }
        public DataTable GetAllProducts()
        {
            SqlParameter[] parameters = new SqlParameter[1];
            parameters[0] = DataLayer.DataAcess.AddParameter("@CategoryID",CategoryID, System.Data.SqlDbType.Int, 20);
            DataTable dt = DataLayer.DataAcess.ExecuteDTbyProcedure("SP_GetAllProducts", parameters);
            return dt;
        }
        internal DataTable GetAvailableStock()
        {
            SqlParameter[] parameters = new SqlParameter[2];
            parameters[0] = DataLayer.DataAcess.AddParameter("@StockType", StockType, System.Data.SqlDbType.Int, 10);
            parameters[1] = DataLayer.DataAcess.AddParameter("@CategoryID", CategoryID, System.Data.SqlDbType.Int, 10);
            DataTable dt = DataLayer.DataAcess.ExecuteDTbyProcedure("SP_GetAvailableStock", parameters);
            return dt;
        }
        internal DataTable SaveCustomerDetails()
        {
            SqlParameter[] parameters = new SqlParameter[7];
            parameters[0] = DataLayer.DataAcess.AddParameter("@CustomerName", CustomerName, System.Data.SqlDbType.VarChar, 100);
            parameters[1] = DataLayer.DataAcess.AddParameter("@CustomerEmailID", CustomerEmailID, System.Data.SqlDbType.VarChar, 100);
            parameters[2] = DataLayer.DataAcess.AddParameter("@CustomerPhoneNo", CustomerPhoneNo, System.Data.SqlDbType.VarChar, 10);
            parameters[3] = DataLayer.DataAcess.AddParameter("@CustomerAddress", CustomerAddress, System.Data.SqlDbType.VarChar, 500);
            parameters[4] = DataLayer.DataAcess.AddParameter("@TotalProducts",TotalProducts, System.Data.SqlDbType.Int, 100);
            parameters[5] = DataLayer.DataAcess.AddParameter("@TotalPrice",TotalPrice,System.Data.SqlDbType.Int,100);
            parameters[6] = DataLayer.DataAcess.AddParameter("@PaymentMethod", PaymentMethod, System.Data.SqlDbType.VarChar, 100);
            DataTable dt = DataLayer.DataAcess.ExecuteDTbyProcedure("SP_SaveCustomerDetails", parameters);
            return dt;
        }
        internal void SaveCustomerProducts()
        {
            SqlParameter[] parameters = new SqlParameter[3];
            parameters[0] = DataLayer.DataAcess.AddParameter("@CustomerID", CustomerID, System.Data.SqlDbType.Int, 20);
            parameters[1] = DataLayer.DataAcess.AddParameter("@ProductID", ProductID, System.Data.SqlDbType.Int, 20);
            parameters[2] = DataLayer.DataAcess.AddParameter("@TotalProduct",TotalProducts, System.Data.SqlDbType.Int, 10);
            DataTable dt = DataLayer.DataAcess.ExecuteDTbyProcedure("SP_SaveCustomerProducts", parameters);
            return;
        }
        internal DataTable GetOrdersList()
        {
            SqlParameter[] parameters = new SqlParameter[1];
            parameters[0] = DataLayer.DataAcess.AddParameter("@Flag", Flag, System.Data.SqlDbType.Int, 20);
            DataTable dt = DataLayer.DataAcess.ExecuteDTbyProcedure("SP_GetOrdersList", parameters);
            return dt;
        }
        internal DataTable GetTransactionDetails()
        {
            SqlParameter[] parameters = new SqlParameter[1];
            parameters[0] = DataLayer.DataAcess.AddParameter("@TransactionNo", Flag, System.Data.SqlDbType.Int, 20);
            DataTable dt = DataLayer.DataAcess.ExecuteDTbyProcedure("SP_GetTransactionDetails", parameters);
            return dt;
        }
        internal DataTable GetSetOrderStatus()
        {
            SqlParameter[] parameters = new SqlParameter[3];
            parameters[0] = DataLayer.DataAcess.AddParameter("@TransactionNo", Convert.ToInt32(OrderNo), System.Data.SqlDbType.Int, 20);
            parameters[1] = DataLayer.DataAcess.AddParameter("@OrderStatus", OrderStatus, System.Data.SqlDbType.VarChar, 300);
            parameters[2] = DataLayer.DataAcess.AddParameter("@Flag", Flag, System.Data.SqlDbType.Int, 10);
            DataTable dt = DataLayer.DataAcess.ExecuteDTbyProcedure("SP_OrderStatus", parameters);
            return dt;
        }
    }
}