﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ShoppingCart.BusinessLayer;
using System.Data;

namespace ShoppingCart
{
    public partial class usCustomerOrder : System.Web.UI.UserControl
    {
        public bool CanIUpdateStatus;
        public string TransactionNoText
        {
            get { return txtTransactionNo.Text; }
            set { txtTransactionNo.Text = value; }
        }
        public bool IsAuthorisedToAddStatus
        {
            set{CanIUpdateStatus=value;}
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                GetTransactionId();
                if (txtTransactionNo.Text != string.Empty)
                {
                    ShowOrderDetails(rblProductDetails.SelectedValue, Convert.ToInt32(txtTransactionNo.Text));
                }
                else
                {
                    rblProductDetails.Visible = false;
                    Panel1.Visible = false;
                    Panel2.Visible = false;
                    Panel3.Visible = false;
                    Panel4.Visible = false;
                }
            }

        }
        public void GetTransactionId()
        {
             ShoppingCartclass k = new ShoppingCartclass();
            DataTable dt = k.GetCustomerId();
            if (dt.Rows.Count > 0)
            {
                 TransactionIddl.DataValueField = "Id"; //for binding the data to the dropdown list all four lines
                //TransactionIddl.DataTextField = "CategoryName";
                TransactionIddl.DataSource = dt;
                TransactionIddl.DataBind();
            }
        }
        private void ShowOrderDetails(string PanelId, int OrderNo)
        {
            Panel1.Visible = false;
            Panel2.Visible = false;
            Panel3.Visible = false;
            Panel4.Visible = false;
            rblProductDetails.Visible = false;
            if (IsOrderNoValid(OrderNo))
            {
                rblProductDetails.Visible = true;
                if (PanelId == "1")
                {
                    ShoppingCartclass k = new ShoppingCartclass
                    {
                        Flag = OrderNo
                    };
                    DataTable dtCustomerDetails = k.GetOrdersList();
                    if (dtCustomerDetails.Rows.Count > 0)
                    {
                        Panel1.Visible = true;
                        lblCustomerName.Text = Convert.ToString(dtCustomerDetails.Rows[0]["CustomerName"]);
                        lblCustomerPhoneNo.Text = Convert.ToString(dtCustomerDetails.Rows[0]["CustomerPhoneNo"]);
                        lblCustomerEmailId.Text = Convert.ToString(dtCustomerDetails.Rows[0]["CustomerEmailId"]);
                        lblPaymentMethod.Text = Convert.ToString(dtCustomerDetails.Rows[0]["PaymentMethod"]);
                        lblTotalPrice.Text = Convert.ToString(dtCustomerDetails.Rows[0]["TotalPrice"]);
                        lblTotalProducts.Text = Convert.ToString(dtCustomerDetails.Rows[0]["TotalProducts"]);
                        txtCustomerAddress.Text = Convert.ToString(dtCustomerDetails.Rows[0]["CustomerAddress"]);

                    }
                }
                if (PanelId == "2")
                {
                    Panel2.Visible = true;
                    ShoppingCartclass k = new ShoppingCartclass
                    {
                        Flag = OrderNo
                    };
                    dlProducts.DataSource = k.GetTransactionDetails();
                    dlProducts.DataBind();
                }
                if (PanelId == "3")
                {
                    Panel3.Visible = true;
                    txtStatus.Visible = CanIUpdateStatus;
                    btnAdd.Visible = CanIUpdateStatus;
                    GetSetOrderStatus(0);
                }
            }
            else
                Panel4.Visible = true; 
        }
        private void GetSetOrderStatus(int Flag)
        {
            ShoppingCartclass k = new ShoppingCartclass
            {
                OrderStatus=txtStatus.Text,
                OrderNo=txtTransactionNo.Text,
                Flag = Flag
            };
            DataTable dt = k.GetSetOrderStatus();
            gvOrderStatus.DataSource = dt;
            gvOrderStatus.DataBind();
            txtStatus.Text = string.Empty;
        }
        private bool IsOrderNoValid(int OrderNo)
        {
            ShoppingCartclass k = new ShoppingCartclass
            {
                Flag = OrderNo
            };
            DataTable dtCustomerDetails = k.GetOrdersList();
            if (dtCustomerDetails.Rows.Count > 0)
                return true;
            else
                return false;
        }
        protected void btnGo_Click(object sender, EventArgs e)
        {
            if(txtTransactionNo.Text!=string .Empty)
            {
                rblProductDetails.Visible = true;
                ShowOrderDetails(rblProductDetails.SelectedValue, Convert.ToInt32(txtTransactionNo.Text));
            }
            else
            {
                rblProductDetails.Visible = false;
                Panel1.Visible = false;
                Panel2.Visible = false;
                Panel3.Visible = false;
                Panel4.Visible = false;
            }
        }

        protected void rblProductDetails_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (txtTransactionNo.Text != string.Empty)
            {
                rblProductDetails.Visible = true;
                ShowOrderDetails(rblProductDetails.SelectedValue, Convert.ToInt32(txtTransactionNo.Text.Trim()));
            }
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            GetSetOrderStatus(1);
        }

        protected void TransactionIddl_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtTransactionNo.Text = TransactionIddl.SelectedIndex.ToString();
        }
    }
}