﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using ShoppingCart.BusinessLayer;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;

namespace ShoppingCart
{
    public partial class Default : System.Web.UI.Page
    {
        public int xl;
        public int ab;
        public int bc;
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)        // To ensure the data is binded only once to home page 
            {
                lblCategoryName.Text = "Popular Products On Shopping Cart Website";
                GetProducts(0); //To get all products
                GetCategory();
               /* if (Request.QueryString["alert"] == "success")
                {
                    Response.Write("<script>alert('Order Placed Successfully and ''" + lblTransactionNo.Text + "')</script>");
                    pnlProducts.Visible = true;
                    pnlCategories.Visible = true;
                    pnlMyCart.Visible = false;
                    pnlEmptyCart.Visible = false;
                    pnlCheckOut.Visible = false;
                    
                    pnlOrderPlacedSuccessfully.Visible = false;
                             
                }*/
                
            }
            lblAvailableStockAlert.Text = string.Empty;   
        }
        private void GetCategory()
        {
            ShoppingCartclass k = new ShoppingCartclass();
            dlCategories.DataSource = null;
            dlCategories.DataSource = k.GetCategories();
            dlCategories.DataBind();
        }
        private void GetProducts(int CategoryID)
        {
            ShoppingCartclass k = new ShoppingCartclass()
            {
                CategoryID=CategoryID
            };
            dlProducts.DataSource=null;
            dlProducts.DataSource = k.GetAllProducts();
            dlProducts.DataBind();
        }
        protected void lblLogo_Click(object sender, EventArgs e)
        {
            lblCategoryName.Text = "Popular Products at Shopping Cart";
            lblProducts.Text = "Products";
            pnlCategories.Visible = true;
            pnlProducts.Visible = true;
            pnlCheckOut.Visible = false;
            pnlEmptyCart.Visible = false;
            pnlMyCart.Visible = false;
            pnlOrderPlacedSuccessfully.Visible = false;
            GetProducts(0);
            HighlightCartProducts();
        }

        protected void btnShoppingCart_Click(object sender, EventArgs e)
        {
            try
            {
                GetMyCart();
                lblCategoryName.Text = "Products in my Shopping Cart";
                lblProducts.Text = "CheckOut Form";
            }
            catch(Exception e1)
            {
                Response.Write("<script>alert('"+e1.StackTrace+"')</script>");
            }
        }

        protected void btnAddToCart_Click(object sender, EventArgs e)
        {
            string ProductID = Convert.ToInt16((((Button)sender).CommandArgument)).ToString();
            string ProductQuantity = "1";

            DataListItem currentItem = (sender as Button).NamingContainer as DataListItem;
            Label lblAvilableStock = currentItem.FindControl("lblAvailableStock") as Label;
            if(Session["MyCart"] !=null)
            {
                DataTable dt = (DataTable)Session["MyCart"];//Coverting Session from else part into DataTable
                var checkProduct = dt.AsEnumerable().Where(r => r.Field<string>("ProductID") == ProductID);
                if(checkProduct.Count()==0)
                {
                    string query = "Select * from products where ProductID=" + ProductID + ";";
                    DataTable dtProducts = GetData(query);
                    DataRow dr = dt.NewRow();
                    dr["ProductID"] = ProductID;
                    dr["Name"] = Convert.ToString(dtProducts.Rows[0]["Name"]);
                    dr["Description"] = Convert.ToString(dtProducts.Rows[0]["Description"]);
                    dr["Price"] = Convert.ToString(dtProducts.Rows[0]["Price"]);
                    dr["ImageUrl"] = Convert.ToString(dtProducts.Rows[0]["ImageUrl"]);            
                    dr["ProductQuantity"] = ProductQuantity;
                    dr["AvailableStock"] = lblAvilableStock.Text;

                    dt.Rows.Add(dr);
                    Session["MyCart"] = dt;
                    btnShoppingCart.Text = dt.Rows.Count.ToString();
                }
                
            }
            else
            {
                string query="Select * from products where ProductID="+ ProductID+"";
                DataTable dtProducts=GetData(query);
                DataTable dt = new DataTable();
                dt.Columns.Add("ProductID",typeof(string));
                dt.Columns.Add("Name",typeof(string));
                dt.Columns.Add("Description",typeof(string));
                dt.Columns.Add("Price",typeof(string));
                dt.Columns.Add("ImageUrl",typeof(string));
                dt.Columns.Add("ProductQuantity",typeof(string));
                dt.Columns.Add("AvailableStock",typeof(string));

                DataRow dr=dt.NewRow();
                dr["ProductID"] = ProductID;
                dr["Name"]=Convert.ToString(dtProducts.Rows[0]["Name"]);
                dr["Description"]=Convert.ToString(dtProducts.Rows[0]["Description"]);
                dr["Price"]=Convert.ToString(dtProducts.Rows[0]["Price"]);
                dr["ImageUrl"]=Convert.ToString(dtProducts.Rows[0]["ImageUrl"]);                
                dr["ProductQuantity"]=ProductQuantity;
                dr["AvailableStock"]=lblAvilableStock.Text; 

                dt.Rows.Add(dr);
                Session["MyCart"] = dt;
                btnShoppingCart.Text = dt.Rows.Count.ToString(); //No of Rows Count is equal to the number of products added to the cart
            }
            HighlightCartProducts();
            
        }
        private void HighlightCartProducts()
        {
            if(Session["MyCart"]!=null)
            {
                DataTable dtProductsAddedToCart = (DataTable)Session["MyCart"];
                if(dtProductsAddedToCart.Rows.Count>0)
                {
                    foreach(DataListItem item in dlProducts.Items)
                    {
                        HiddenField hfProductID = item.FindControl("hfProductID") as HiddenField;
                        if (dtProductsAddedToCart.AsEnumerable().Any(row => hfProductID.Value == row.Field<String>("ProductID")))
                        {
                            Button btnAddToCart = item.FindControl("btnAddToCart") as Button;
                            btnAddToCart.BackColor = System.Drawing.Color.Green;
                            btnAddToCart.Text = "Added To Cart";
                        }
                    }
                }
            }
        }
        protected void dlCategories_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        protected void lbtnCategory_Click(object sender, EventArgs e)//to get the products specific to that category
        {
            pnlMyCart.Visible = false;
            pnlProducts.Visible = true;
            int CategoryID = Convert.ToInt16((((LinkButton)sender).CommandArgument));
            GetProducts(CategoryID);
            HighlightCartProducts();
        }

        protected void txtProductQuantity_TextChanged(object sender, EventArgs e)//changing the product quantity
        {
            TextBox txtQuantity = (sender as TextBox);
            DataListItem currentItem = (sender as TextBox).NamingContainer as DataListItem;
            HiddenField ProductID = currentItem.FindControl("hfProductID") as HiddenField;
            Label lblAvailableStock=currentItem.FindControl("lblAvailbleStock") as Label;
            if(txtQuantity.Text==string.Empty ||txtQuantity.Text=="0" || txtQuantity.Text=="1")
            {
                txtQuantity.Text = "1";
                DataTable dt = (DataTable)Session["MyCart"];
            }
                
            else
            {
                
                    if (Session["MyCart"] != null)
                    {
                        int ab, bc;
                        if (Int32.TryParse(txtQuantity.Text, out ab) && Int32.TryParse(lblAvailableStock.Text, out bc))
                        {
                            if (ab <= bc)
                            {
                                DataTable dt = (DataTable)Session["MyCart"];
                                DataRow[] rows = dt.Select("ProductID'" + ProductID.Value + "'");
                                int index = dt.Rows.IndexOf(rows[0]);
                                dt.Rows[index]["ProductQuantity"] = txtQuantity.Text;
                                Session["MyCart"] = dt;

                            }
                            else
                            {
                                lblAvailableStockAlert.Text = "Alert:Product BuyOut Should not be more than available Stock";
                                txtQuantity.Text = "1";

                            }
                        }
                    }
                      
            }
            UpdateTotalBill();
        }

        protected void btnPlaceOrder_Click(object sender, EventArgs e)
        {
            string productids = string.Empty;
            DataTable dt;
            if(Session["MyCart"]!=null)
            {
                dt = (DataTable)Session["MyCart"];
                ShoppingCartclass k = new ShoppingCartclass()
                {
                    CustomerName=txtCustomerName.Text,
                    CustomerAddress=txtCustomerAddress.Text,
                    CustomerPhoneNo=txtCustomerPhoneNo.Text,
                    CustomerEmailID=txtCustomerEmailID.Text,
                    TotalProducts=Convert.ToInt32(txtTotalProducts.Text),
                    TotalPrice=Convert.ToInt32(txtTotalPrice.Text),
                    ProductList=productids,
                    PaymentMethod=rblPaymentMethod.SelectedItem.Text,
                };
                DataTable dtResult= k.SaveCustomerDetails();
                for (int i = 0; i <dt.Rows.Count;i++ )
                {
                    ShoppingCartclass SaveProducts = new ShoppingCartclass()
                    {
                        CustomerID = Convert.ToInt32(dtResult.Rows[0][0]),
                        ProductID = Convert.ToInt32(dt.Rows[i]["ProductID"]),
                        TotalProducts = Convert.ToInt32(dt.Rows[i]["ProductQuantity"]),

                    };
                    SaveProducts.SaveCustomerProducts();
                }
                    Session.Clear();
                    GetMyCart();
                    lblTransactionNo.Text = "Your Transaction No is:" + dtResult.Rows[0][0];

                    pnlOrderPlacedSuccessfully.Visible = true;
                    pnlProducts.Visible = false;
                    pnlMyCart.Visible = false;
                    pnlMyCart.Visible = false;
                    pnlEmptyCart.Visible = false;
                    pnlCheckOut.Visible = false;
                    pnlCategories.Visible = false;
                    
                   

                    SendOrderPlacedAlert(txtCustomerName.Text, txtCustomerEmailID.Text, Convert.ToString(dtResult.Rows[0][0]));

                    txtCustomerAddress.Text = String.Empty;
                    txtCustomerEmailID.Text = String.Empty;
                    txtCustomerName.Text = String.Empty;
                    txtCustomerPhoneNo.Text = String.Empty;
                    txtTotalPrice.Text = "0";
                    txtTotalProducts.Text = "0";


                   // Response.Redirect("~/Admin/Default.aspx?alert=success");
                    

                
            }

        }
        private void GetMyCart() //showing data in empty cart and mycart
        {
            try
            {
                DataTable dtProducts=new DataTable();
                if (Session["MyCart"] != null)
                {
                    dtProducts = (DataTable)Session["MyCart"];
                }
                else
                {
                    dtProducts = new DataTable();
                }
                if (dtProducts.Rows.Count > 0)
                {

                    txtTotalProducts.Text = dtProducts.Rows.Count.ToString();
                    btnShoppingCart.Text = dtProducts.Rows.Count.ToString();
                    dlCartProducts.DataSource = dtProducts;
                    dlCartProducts.DataBind();
                    UpdateTotalBill();

                    pnlMyCart.Visible = true;
                    pnlCheckOut.Visible = true;
                    pnlEmptyCart.Visible = false;
                    pnlOrderPlacedSuccessfully.Visible = false;
                    pnlProducts.Visible = false;
                    pnlCategories.Visible = false;

                }
                else
                {
                    //lblCategoryName.Text = "";
                    //lblProducts.Text = "";
                    pnlEmptyCart.Visible = true;
                    pnlMyCart.Visible = false;
                    pnlCheckOut.Visible = false;
                    pnlOrderPlacedSuccessfully.Visible = false;
                    pnlProducts.Visible = false;
                    pnlCategories.Visible = false;

                    dlCartProducts.DataSource = null;
                    dlCartProducts.DataBind();
                    txtTotalProducts.Text = "0";
                    txtTotalPrice.Text = "0";
                    btnShoppingCart.Text = "0";
                }
            }
            catch (Exception e1)
            {
                Response.Write("<script>alert('" + e1.StackTrace + "')</script>");
            }
            
        }
        private void UpdateTotalBill()
        {
            try
            {
                long TotalPrice = 0;
                long TotalProducts = 0;
                foreach (DataListItem item in dlCartProducts.Items)
                {
                    Label PriceLabel = item.FindControl("lblPrice") as Label;
                    TextBox ProductQuantity = item.FindControl("txtProductQuantity") as TextBox;
                    long x = Convert.ToInt64(PriceLabel.Text);
                    long y = Convert.ToInt64(ProductQuantity.Text);
                    long ProductPrice = x * y;
                    TotalPrice = TotalPrice + ProductPrice;
                    TotalProducts = TotalProducts + Convert.ToInt32(ProductQuantity.Text);
                }
                txtTotalPrice.Text = Convert.ToString(TotalPrice);
                txtTotalProducts.Text = Convert.ToString(TotalProducts);
            }
            catch (Exception e1)
            {
                
                Response.Write("<script>alert('" + e1.StackTrace + "')</script>");
            }
           
        }

       protected void btnRemoveFromCart_Click(object sender, EventArgs e)
       {
           string ProductID = Convert.ToInt16(((Button)sender).CommandArgument).ToString();
           if(Session["MyCart"]!=null)
           {
               DataTable dt = (DataTable)Session["MyCart"];
               DataRow drr = dt.Select("ProductID=" + ProductID + "").FirstOrDefault();
               if(drr!=null)
               {
                   dt.Rows.Remove(drr);
               }
               Session["MyCart"] = dt;
           }
           GetMyCart();
       }

       public DataTable GetData(string query)
       {
           DataTable dt = new DataTable();
           String Conn = ConfigurationManager.ConnectionStrings["MyCon"].ConnectionString;
           SqlConnection con = new SqlConnection(Conn);
           con.Open();
           SqlDataAdapter da = new SqlDataAdapter(query, con);
           da.Fill(dt);
           con.Close();
           return dt;
       }
       private string PopulateOrderEmailBody(string CustomerName, string TransactionNo)
       {
           string body = string.Empty;
           using (StreamReader reader = new StreamReader(Server.MapPath("~/OrderTemplate.html")))
           {
               body = reader.ReadToEnd();
           }
           body = body.Replace("{CustomerName}", CustomerName);
           body = body.Replace("{OrderNo}", TransactionNo);
           body = body.Replace("{TransactionUrl}", "http://OldBooksShoppingCart.in/TrackYourOrder.aspx?Id="+ TransactionNo);
           return body;
       }
           
       private void SendOrderPlacedAlert(string CustomerName,string CustomerEmailID,string TransactionNo)
       {
           string body = this.PopulateOrderEmailBody(CustomerName, TransactionNo);
           EmailEngine.SendEmail(CustomerEmailID, "Shopping Cart----Your Email Details", body);
       }

       protected void dlProducts_SelectedIndexChanged(object sender, EventArgs e)
       {

       }

       protected void dlCartProducts_SelectedIndexChanged(object sender, EventArgs e)
       {

       }       
    }
}